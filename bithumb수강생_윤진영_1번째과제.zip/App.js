import React from 'react';
import './App.css';

class App extends React.Component {
  render(){
    //map, concat 에 쓰일 배열
    const menus = [
     "안녕하세요!",
     "비트 캠프 수강생인 윤진영이라고 합니다.",
     "올해 대학을 졸업해서 아직 모르는게 많지만",
     "열심히 수업 따라가겠습니다!",
     "감사합니다:)"
    ]
    
    const name = ["빨리 수업 듣고싶습니다!"]
    //map 예제
    const menuList = menus.map((menu, i) => (<li key={i}>{menu}</li>));
    //concat, 화살표 함수에서 쓰일 배열
    const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    //concat 예제
    const concatDemo = menuList.concat(<li>{name}</li>);
    //filter 예제
    const filterDemo = arr.filter(a => a%2==0);
    //화살표 함수 예제
    const arrowDemo = arr.map(ar => ar*2);
    
    return (
    <p>
     
    <h2>1.map() 함수</h2>
      <ul>
        {menuList}
      </ul>

      <h2>2.concat() 함수</h2>
      <ul>
      {concatDemo}
      </ul>

      <h2>3.filter() 함수</h2>
      <h3>&nbsp;&nbsp;[arr 배열 : {arr}]</h3>
      <ul><li>arr 배열에서 짝수 구하기.</li><br/>
      <li>짝수 : {filterDemo}</li>
      </ul>

      <h2>4.화살표 함수</h2>
      <h3>&nbsp;&nbsp;arr 배열 각 항목마다 *2 구하기.</h3>
      <ul>
      <li>{arrowDemo}</li>    </ul>
      <ul><li>배열에 있는 인덱스를 띄어쓰기해서 띄우고 싶은데 어떻게 해야되는지 모르겠습니다.</li></ul>

      </p>

    );
  }
}
export default App;
